module Quiz_Manager {
	requires java.sql;
}