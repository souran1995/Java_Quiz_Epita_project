package fr.epita.constants;

public class Constants {

}
