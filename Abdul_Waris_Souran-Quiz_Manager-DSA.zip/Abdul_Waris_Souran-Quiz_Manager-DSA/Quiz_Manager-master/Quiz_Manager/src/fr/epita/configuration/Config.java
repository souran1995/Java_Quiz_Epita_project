package fr.epita.configuration;

public   class Config {

	public static final String URL_CONNECTION="jdbc:ucanaccess://C:\\Java_Homework\\Quiz_Manager\\Quiz_Manager.accdb";
	
	
	
	public static void displayQueriesInConsole(String query) {
		//System.out.println(query);
		
	}
}
